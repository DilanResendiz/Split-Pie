import { Link } from "react-router-dom";
import logoUrl from "../assets/logo.png";

export default function Navbar() {
  return (
    <header className="nav">
      <div className="nav__left">
        <img src={logoUrl} alt="SplitPie" className="nav__logo" />
        <span className="nav__brand">Split Pie</span>
      </div>
      <nav className="nav__right">
        <Link to="/" className="nav__link">Home</Link>
        <a href="#about" className="nav__link">About</a>
        {/* este es el botón */}
        <Link to="/split" className="btn btn--primary">Split Payment</Link>
      </nav>
    </header>
  );
}
