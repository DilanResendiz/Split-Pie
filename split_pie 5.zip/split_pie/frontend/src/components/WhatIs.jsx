export default function WhatIs() {
  return (
    <section className="grid grid--image-card" id="about">
      <div className="grid__image">
        <img
          src="https://images.unsplash.com/photo-1522202176988-66273c2fd55f?q=80&w=1600&auto=format&fit=crop"
          alt="Friends paying at a restaurant"
        />
      </div>

      <aside className="grid__card">
        <h3 className="card__title">WHAT IS SPLIT PIE?</h3>
        <p className="card__text">
          We are the solution for every problem you face when splitting expenses with others.
          Our platform eliminates the stress of reminding, and chasing payments.
          With just a few clicks, you can create a shared bill, invite friends or family,
          and let each person pay their part securely through their own digital wallet.
        </p>
        <a href="#about" className="card__link">ABOUT US</a>
      </aside>
    </section>
  )
}
