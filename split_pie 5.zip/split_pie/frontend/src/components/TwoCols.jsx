export default function TwoCols() {
  return (
    <section className="twocols">
      <div className="twocols__col">
        <h3 className="twocols__title">YOU DON’T NEED TO BE AN EXPERT</h3>
        <p className="twocols__text">
          Managing group expenses shouldn’t be complicated. With SplitPie, you don’t need
          financial skills or advanced apps — everything is calculated automatically so you
          can focus on enjoying the moment, not the math.
        </p>
      </div>
      <div className="twocols__col">
        <h3 className="twocols__title">TRY IT NOW !!!</h3>
        <p className="twocols__text">
          Start your first shared payment in seconds. No tutorials, no steep learning curve —
          just create a group, share the link, and let everyone pay their part securely and transparently.
        </p>
      </div>
    </section>
  )
}
