import { Link } from "react-router-dom";

export default function CTA() {
  return (
    <section className="cta" id="split">
      <div className="cta__inner">
        <h3 className="cta__title">SPLIT ACCOUNT</h3>
        <p className="cta__subtitle">WHAT WE BELIEVE IN</p>
        <Link
  to="/split"
  className="btn btn--primary"
  style={{ backgroundColor: "#cbcae7ff", color: "black" }}
                                                            >
                                                  Split Payment
                                                      </Link>
      </div>
    </section>
  )
}
