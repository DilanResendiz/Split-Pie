import pieUrl from '../assets/logo.png'

export default function Hero() {
  return (
    <section className="hero">
      <div className="hero__title">
        <h1 className="title title--big">
          <span>SPLIT BILLS</span><span className="dot">.</span>
        </h1>
        <h2 className="title title--accent">STAY CHILL</h2>
      </div>
      <img src={pieUrl} alt="Pie icon" className="hero__pie" />
    </section>
  )
}
