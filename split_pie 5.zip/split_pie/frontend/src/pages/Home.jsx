import Hero from '../components/Hero.jsx'
import WhatIs from '../components/WhatIs.jsx'
import TwoCols from '../components/TwoCols.jsx'
import CTA from '../components/CTA.jsx'

export default function Home() {
  return (
    <main>
      <Hero />
      <WhatIs />
      <TwoCols />
      <CTA />
    </main>
  )
}
