import { useMemo, useState } from "react";
import "../styles/split.css";
import userIcon from "../assets/user.png";

/**
 * Reparte el total en partes iguales al centavo (trabajando en centavos).
 */
function distribute(totalNumber, n) {
  const centsTotal = Math.round((Number(totalNumber) || 0) * 100);
  const count = Math.max(1, n);
  const base = Math.floor(centsTotal / count);
  const parts = Array(count).fill(base);
  let leftover = centsTotal - base * count;
  for (let i = 0; i < parts.length && leftover > 0; i++) {
    parts[i] += 1;
    leftover--;
  }
  return parts.map(c => (c / 100).toFixed(2));
}

// URL base del API: si existe VITE_API_URL la usa, si no usa proxy de Vite (/api)
const API_BASE = import.meta.env.VITE_API_URL || "";
const PAYMENTS_URL = `${API_BASE}/api/payments`;

export default function SplitPayment() {
  const [invoiceLink, setInvoiceLink] = useState("");
  const [total, setTotal] = useState("");
  const [rows, setRows] = useState([{ name: "", email: "", amount: "" }]);

  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState(null);

  const totalNumber = useMemo(() => Number(total) || 0, [total]);

  const autoAmounts = useMemo(
    () => distribute(totalNumber, rows.length),
    [totalNumber, rows.length]
  );

  const sum = useMemo(
    () => autoAmounts.reduce((acc, v) => acc + Number(v || 0), 0),
    [autoAmounts]
  );
  const pending = +(totalNumber - sum).toFixed(2);

  const addRow = () => setRows(r => [...r, { name: "" }]);
  const updateRowName = (i, value) => {
  setRows(r => r.map((row, idx) => (
    idx === i ? { ...row, name: value } : row
  )));
};

const updateRowEmail = (i, value) => {
  setRows(r => r.map((row, idx) => (
    idx === i ? { ...row, email: value } : row
  )));
};

  const removeRow = (i) => {
    setRows(r => (r.length > 1 ? r.filter((_, idx) => idx !== i) : r));
  };

  async function handleSubmit() {
    setMsg(null);

    // Validaciones básicas
    if (!invoiceLink.trim()) {
      setMsg("Please paste a link.");
      return;
    }
    if (totalNumber <= 0) {
      setMsg("Total must be greater than 0.");
      return;
    }
    if (rows.length < 1) {
      setMsg("Add at least one participant.");
      return;
    }

    // Construimos payload
    const participants = rows.map((r, i) => ({
      name: r.name?.trim() || `Participant ${i + 1}`,
      email: r.email?.trim() || "",
      amount: Number(autoAmounts[i]) // número, no string
      
    }));

    const payload = {
      link: invoiceLink.trim(),
      total: totalNumber,
      participants
    };
    const invalid = rows.find(r => r.email && !/^\S+@\S+\.\S+$/.test(r.email));
if (invalid) { setMsg("Please enter valid emails."); return; }

    try {
      setLoading(true);
      const res = await fetch(PAYMENTS_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload)
      });
      if (!res.ok) {
        const errText = await res.text().catch(() => "");
        throw new Error(`API ${res.status}: ${errText || "request failed"}`);
      }
      const data = await res.json();
      setMsg("Payment created successfully ✅");
      console.log("Created:", data);
      // Si quieres limpiar el formulario:
      // setInvoiceLink(""); setTotal(""); setRows([{ name: "" }]);
    } catch (err) {
      console.error(err);
      setMsg(`Error creating payment: ${err.message}`);
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="split">
      <section className="split__hero">
        <h1 className="split__title">
          <span>SPLIT</span> <span className="accent">PAYMENT</span>
        </h1>
      </section>

      <hr className="split__divider" />

      <section className="split__form">
        <h2 className="split__subtitle">FILL THE NEXT FIELDS</h2>

        {/* Mensaje de estado */}
        {msg && (
          <div
            style={{
              background: "#fff8d1",
              border: "1px solid #e6d780",
              borderRadius: 8,
              padding: ".6rem .8rem",
              marginBottom: ".8rem",
              fontWeight: 600
            }}
          >
            {msg}
          </div>
        )}

        {/* Link + Total */}
        <div className="row row--top">
          <input
            className="input input--wide"
            placeholder="Paste the link…"
            value={invoiceLink}
            onChange={e => setInvoiceLink(e.target.value)}
          />
          <input
            className="input input--amount"
            type="number"
            inputMode="decimal"
            step="0.01"
            placeholder="$$"
            value={total}
            onChange={e => setTotal(e.target.value)}
          />
        </div>

        {/* Participantes (monto auto) */}
        {rows.map((r, i) => (
          <div className="row row--person" key={i}>
            <img src={userIcon} alt="" className="avatar" />
            <input
              className="input input--person"
              placeholder="Name or wallet…"
              value={r.name}
              onChange={e => updateRowName(i, e.target.value)}
            />
            <input
     className="input input--person"
     placeholder="Email…"
     type="email"
     value={r.email || ""}
     onChange={e => updateRowEmail(i, e.target.value)}
     style={{ maxWidth: 320 }}   // ajusta a tu gusto
   />
            <div className="currency">$</div>
            <input
              className="input input--mini"
              type="number"
              inputMode="decimal"
              step="0.01"
              value={autoAmounts[i] ?? ""}
              readOnly
              aria-label={`Amount for row ${i + 1}`}
            />
            {rows.length > 1 && (
              <button
                type="button"
                className="add-btn"
                title="Remove participant"
                onClick={() => removeRow(i)}
                style={{ color: "#b00", borderColor: "#b00" }}
              >
                –
              </button>
            )}
          </div>
        ))}

        {/* Agregar participante */}
        <div className="row row--add">
          <span className="dots">…</span>
          <button
            type="button"
            className="add-btn"
            onClick={addRow}
            aria-label="Add participant"
          >
            +
          </button>
        </div>

        {/* Resumen */}
        <div className="row row--summary">
          <span className="muted">Sum: ${sum.toFixed(2)}</span>
          <span className="muted">Pending: ${pending.toFixed(2)}</span>
        </div>

        {/* CTA -> llama al backend */}
        <div className="row row--cta">
          <button
            className="btn btn--primary btn--lg"
            onClick={handleSubmit}
            disabled={loading}
            style={{ opacity: loading ? 0.7 : 1 }}
          >
            {loading ? "PROCESSING…" : "SPLIT PAYMENT"}
          </button>
        </div>
      </section>
    </main>
  );
}
