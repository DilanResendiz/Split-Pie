const BASE_URL = import.meta.env.VITE_API_URL || "http://localhost:4000";

export async function createPayment(payload) {
  const res = await fetch(`${BASE_URL}/api/payments`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload)
  });
  if (!res.ok) throw new Error(`API error ${res.status}`);
  return res.json();
}

export async function listPayments() {
  const res = await fetch(`${BASE_URL}/api/payments`);
  if (!res.ok) throw new Error(`API error ${res.status}`);
  return res.json();
}
