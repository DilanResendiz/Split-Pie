import fetch from 'node-fetch';
import fs from 'fs';

const data = JSON.parse(fs.readFileSync('test.json', 'utf-8'));

async function testPago() {
  const res = await fetch('http://localhost:4000/pagar', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });

  const json = await res.json();
  console.log(json);
}

testPago();