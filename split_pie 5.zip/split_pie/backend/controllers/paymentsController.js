// backend/controllers/paymentsController.js
import db from "../models/db.js";

// GET /api/payments -> lista pagos + participantes (para debug)
export const listPayments = (_req, res) => {
  const payments = db.prepare(`SELECT * FROM payments ORDER BY id DESC`).all();
  const participants = db.prepare(`SELECT * FROM participants`).all();
  res.json({ payments, participants });
};

// GET /api/payments/:id -> pago con participantes
export const getPayment = (req, res) => {
  const { id } = req.params;
  const payment = db.prepare(`SELECT * FROM payments WHERE id = ?`).get(id);
  if (!payment) return res.status(404).json({ error: "not found" });
  const parts = db
    .prepare(`SELECT * FROM participants WHERE payment_id = ? ORDER BY id`)
    .all(id);
  res.json({ ...payment, participants: parts });
};

// POST /api/payments -> guarda un split nuevo
export const createPayment = (req, res) => {
  const { link, total, participants = [] } = req.body;

  if (!link || !total) {
    return res.status(400).json({ error: "link and total are required" });
  }

  const now = new Date().toISOString();

  const insertPayment = db.prepare(`
    INSERT INTO payments (link, total, status, created_at)
    VALUES (?, ?, 'created', ?)
  `);
  const insertParticipant = db.prepare(`
    INSERT INTO participants (payment_id, name, email, payer_wallet, amount, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
  `);

  const tx = db.transaction(() => {
    const result = insertPayment.run(link, Number(total), now);
    const paymentId = result.lastInsertRowid;
    for (const p of participants) {
      insertParticipant.run(
        paymentId,
        p.name || "Participant",
        Number(p.amount) || 0
      );
    }
    return paymentId;
  });

  const id = tx();
  res.status(201).json({ id, link, total: Number(total), status: "created", created_at: now });
};

// (Opcional) POST /api/payments/:id/confirm/:participantId -> marcar pagado
export const confirmParticipant = (req, res) => {
  const { id, participantId } = req.params;
  const result = db
    .prepare(`UPDATE participants SET paid = 1 WHERE id = ? AND payment_id = ?`)
    .run(participantId, id);

  if (result.changes === 0) return res.status(404).json({ error: "not found" });
  res.json({ ok: true });
};
