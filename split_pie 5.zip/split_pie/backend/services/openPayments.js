import { createAuthenticatedClient, isFinalizedGrant } from "@interledger/open-payments";
import nodemailer from "nodemailer";

// usa variables de entorno para el correo
const transporter = nodemailer.createTransport({
  service: "gmail",
  auth: { user: process.env.EMAIL_USER, pass: process.env.EMAIL_PASS }
});

/**
 * Paso 1: prepara el pago (incoming, quote y grant de outgoing con link)
 * Retorna {incomingPayment, quote, redirect, continueUri, continueAccessToken}
 */
export async function startPayment({
  amountValue,                // string o number, en centavos si scale=2
  payer: { walletAddressUrl, privateKeyJwk, keyId, email },
  receiverWalletAddressUrl
}) {
  const client = await createAuthenticatedClient({
    walletAddressUrl,
    privateKey: privateKeyJwk,
    keyId,
  });

  const payerWallet = await client.walletAddress.get({ url: walletAddressUrl });
  const receiverWallet = await client.walletAddress.get({ url: receiverWalletAddressUrl });

  // 1) Grant receptor -> crear incoming
  const incomingGrant = await client.grant.request(
    { url: receiverWallet.authServer },
    { access_token: { access: [{ type: "incoming-payment", actions: ["create"] }] } }
  );
  if (!isFinalizedGrant(incomingGrant)) throw new Error("Incoming grant not finalized");

  const incomingPayment = await client.incomingPayment.create(
    { url: receiverWallet.resourceServer, accessToken: incomingGrant.access_token.value },
    {
      walletAddress: receiverWallet.id,
      incomingAmount: {
        assetCode: receiverWallet.assetCode,
        assetScale: receiverWallet.assetScale,
        value: String(amountValue),
      },
      description: "SplitPie contribution"
    }
  );

  // 2) Grant quote (payer) -> crear quote
  const quoteGrant = await client.grant.request(
    { url: payerWallet.authServer },
    { access_token: { access: [{ type: "quote", actions: ["create"] }] } }
  );
  if (!isFinalizedGrant(quoteGrant)) throw new Error("Quote grant not finalized");

  const quote = await client.quote.create(
    { url: receiverWallet.resourceServer, accessToken: quoteGrant.access_token.value },
    { walletAddress: payerWallet.id, receiver: incomingPayment.id, method: "ilp" }
  );

  // 3) Grant outgoing con interacción (redirect)
  const outgoingGrant = await client.grant.request(
    { url: payerWallet.authServer },
    {
      access_token: {
        access: [
          { type: "outgoing-payment", actions: ["create"], limits: { debitAmount: quote.debitAmount }, identifier: payerWallet.id }
        ]
      },
      interact: { start: ["redirect"] },
    }
  );

  const redirect = outgoingGrant?.interact?.redirect;
  const continueUri = outgoingGrant?.continue?.uri;
  const continueAccessToken = outgoingGrant?.continue?.access_token?.value;

  // Enviar correo al pagador
  if (email && redirect) {
    await transporter.sendMail({
      from: `"SplitPie" <${process.env.EMAIL_USER}>`,
      to: email,
      subject: "Confirma tu pago",
      html: `<p>Confirma tu pago con tu wallet:</p><p><a href="${redirect}">${redirect}</a></p>`
    });
  }

  return {
    incomingPayment,
    quote,
    redirect,
    continueUri,
    continueAccessToken
  };
}

/**
 * Paso 2: continuar (tras la autorización) y crear el outgoing payment
 * Retorna {outgoingPayment}
 */
export async function finishPayment({
  walletAddressUrl,           // payer wallet again
  privateKeyJwk,
  keyId,
  continueUri,
  continueAccessToken,
  quoteId
}) {
  const client = await createAuthenticatedClient({
    walletAddressUrl,
    privateKey: privateKeyJwk,
    keyId,
  });

  const payerWallet = await client.walletAddress.get({ url: walletAddressUrl });

  const finalizedGrant = await client.grant.continue({
    url: continueUri,
    accessToken: continueAccessToken
  });
  if (!isFinalizedGrant(finalizedGrant)) throw new Error("Outgoing grant not finalized");

  const outgoingPayment = await client.outgoingPayment.create(
    { url: payerWallet.resourceServer, accessToken: finalizedGrant.access_token.value },
    { walletAddress: payerWallet.id, quoteId }
  );

  return { outgoingPayment };
}
