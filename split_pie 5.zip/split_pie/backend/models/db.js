// backend/models/db.js
import Database from "better-sqlite3";
import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Carpeta /backend/data (si no existe, la creamos)
const dataDir = path.join(__dirname, "..", "data");
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

// Archivo SQLite
const dbPath = path.join(dataDir, "app.db");
console.log("🔎 Using DB:", dbPath);
const db = new Database(dbPath);

// Esquema
db.exec(`
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    link TEXT NOT NULL,
    total REAL NOT NULL,
    receiver_wallet TEXT,         -- <- si lo usas con Open Payments
    incoming_id TEXT,             -- <- URL del incoming payment (opcional)
    status TEXT NOT NULL DEFAULT 'created',
    created_at TEXT NOT NULL DEFAULT (datetime('now'))
  );

  CREATE TABLE IF NOT EXISTS participants (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    payment_id INTEGER NOT NULL,
    name TEXT,
    email TEXT,                   -- <- aquí guardamos el correo
    payer_wallet TEXT,            -- si lo usas
    key_id TEXT,                  -- si lo usas
    quote_id TEXT,
    outgoing_id TEXT,
    amount REAL NOT NULL,
    grant_redirect_url TEXT,
    paid INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now')),
    FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE CASCADE
  );

  CREATE INDEX IF NOT EXISTS idx_participants_payment
    ON participants(payment_id);
`);

export default db;
