import express from "express";
import cors from "cors";
import morgan from "morgan";
import dotenv from "dotenv";
import path from "path";
import { fileURLToPath } from "url";
import Database from "better-sqlite3";
import fs from "fs";
import{ pagoMultiple } from "./logica.js";

import paymentRoutes from "./routes/payments.js";

dotenv.config();
const app = express();

// === rutas absolutas útiles ===
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, "data", "app.db");

// Middlewares
app.use(express.json());
app.use(morgan("dev"));
app.use(
  cors({
    origin: process.env.FRONTEND_ORIGIN || "http://localhost:5173",
    credentials: true,
  })
);

// ===== Base de datos =====
console.log("Using DB:", DB_PATH);
const db = new Database(DB_PATH);

// ---- Función para leer datos de la DB ----
export function getData() {
  const wallet_col = db.prepare(
    "SELECT name FROM participants ORDER BY id DESC LIMIT 4"
  ).all();
  const wallet = wallet_col.map((w) => w.name);

  const email_col = db.prepare(
    "SELECT email FROM participants ORDER BY id DESC LIMIT 4"
  ).all();
  const email = email_col.map((e) => e.email);

  const privateKey1 = fs.readFileSync("private1.key", "utf-8");
  const privateKey2 = fs.readFileSync("private2.key", "utf-8");
  const privateKey3 = fs.readFileSync("private3.key", "utf-8");
  const privateKey4 = fs.readFileSync("private4.key", "utf-8");

  const privateKeys = [privateKey1, privateKey2, privateKey3, privateKey4];

  const keyID = ["1c6d2627-c0f6-43bd-89db-8246e0013c0f", "081a663e-3248-4584-9f34-c3143fa4bfde", "00472da4-a96f-4dd7-9941-97aadb7f9f72", "081a663e-3248-4584-9f34-c3143fa4bfde"];

  // OJO: la tabla es 'payments' (plural)
  const paymentWallet = db
    .prepare("SELECT link FROM payments ORDER BY id DESC LIMIT 1")
    .get();
  const monto = db
    .prepare("SELECT total FROM payments ORDER BY id DESC LIMIT 1")
    .get();

  return { wallet, email, privateKeys, keyID, paymentWallet, monto };
}

// ====== NUEVO: watcher del archivo SQLite ======
function onDatabaseChange() {
  try {
    // aquí puedes encadenar otras funciones si quieres
    const snapshot = getData();
    console.log("📦 DB updated. Latest snapshot:", snapshot);
    // ejemplo: notificar por websockets / SSE / colas, etc.
    pagoMultiple(4, snapshot.paymentWallet, snapshot.wallet, snapshot.email, snapshot.privateKeys, snapshot.keyID);
  } catch (err) {
    console.error("❌ Error reading DB after change:", err);
  }
}

// Debounce para evitar múltiples ejecuciones por una sola escritura
let dbChangeTimer = null;
function watchAppDb() {
  if (!fs.existsSync(DB_PATH)) {
    console.warn("⚠️ app.db not found yet. Watcher will start when it appears.");
  }

  // fs.watchFile funciona mejor para SQLite (polling por mtime)
  fs.watchFile(DB_PATH, { interval: 500 }, (curr, prev) => {
    if (curr.mtimeMs !== prev.mtimeMs) {
      clearTimeout(dbChangeTimer);
      dbChangeTimer = setTimeout(() => onDatabaseChange(), 300);
    }
  });

  console.log("👀 Watching DB file:", DB_PATH);
}
// inicia el watcher
watchAppDb();

// ================== API routes ==================
app.get("/api/health", (_req, res) => res.json({ ok: true }));
app.use("/api/payments", paymentRoutes);

// === Servir frontend compilado ===
app.use(express.static(path.join(__dirname, "../frontend/dist")));

// Fallback para React Router (ej: /split, /about)
app.get("*", (_req, res) => {
  res.sendFile(path.join(__dirname, "../frontend/dist/index.html"));
});

// Start server
const PORT = process.env.PORT || 4000;
app.listen(PORT, () =>
  console.log(`✅ API + Frontend on http://localhost:${PORT}`)
);

