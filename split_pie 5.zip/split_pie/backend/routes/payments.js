import { Router } from "express";
import db from "../models/db.js";

const router = Router();

/**
 * Body esperado
 * {
 *   link: "https://loquesea.com",
 *   total: 199.00,
 *   receiverWallet?: "https://ilp.interledger-test.dev/xxx",   // opcional
 *   participants: [
 *     { name: "Ana", email: "ana@dom.com", amount: 99.5, payerWallet?: "..." },
 *     { name: "Luis", email: "luis@dom.com", amount: 99.5, payerWallet?: "..." }
 *   ]
 * }
 */

// Crear pago + participantes
router.post("/", (req, res) => {
  const { link, total, receiverWallet, participants } = req.body || {};

  // Validaciones mínimas
  if (!link || typeof total !== "number" || !Array.isArray(participants) || participants.length === 0) {
    return res.status(400).json({ error: "Invalid payload" });
  }

  // Preparar statements
  const insertPayment = db.prepare(`
    INSERT INTO payments (link, total, receiver_wallet, status, created_at)
    VALUES (?, ?, ?, 'created', datetime('now'))
  `);

  const insertParticipant = db.prepare(`
  INSERT INTO participants
  (payment_id, name, amount, email) 
  VALUES (?, ?, ?, ?)
`);

  // Transacción para consistencia
  const tx = db.transaction(() => {
    const result = insertPayment.run(link, total, receiverWallet || null);
    const paymentId = result.lastInsertRowid;

    for (const p of participants) {
  insertParticipant.run(
    paymentId,
    (p.name || "").trim(),
    Number(p.amount) || 0,
    (p.email || "").trim() || null
  );
}


    return paymentId;
  });

  try {
    const paymentId = tx();
    return res.status(201).json({ id: paymentId, ok: true });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: "DB transaction failed" });
  }
});

// Obtener un pago con sus participantes (para mostrar en UI)
router.get("/:id", (req, res) => {
  const id = Number(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid id" });

  const payment = db.prepare(`SELECT * FROM payments WHERE id = ?`).get(id);
  if (!payment) return res.status(404).json({ error: "Not found" });

  const participants = db.prepare(`
    SELECT id, name, email, payer_wallet AS payerWallet, amount, paid, quote_id AS quoteId, outgoing_id AS outgoingId
    FROM participants
    WHERE payment_id = ?
    ORDER BY id ASC
  `).all(id);

  res.json({ ...payment, participants });
});

export default router;
